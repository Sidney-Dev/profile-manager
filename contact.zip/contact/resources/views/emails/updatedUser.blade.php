<h1>Updated User</h1>
<div id="user_box">
    <p>Dear {{ $userNew->name }}</p>
    <p>This is a confirmation that your email on Full Stack Test has been changed to: <br>
    {{ $userNew->email }}
</p>
</div>