<h1>Updated User</h1>
<div id="user_box">
    <p>Dear <?php echo e($userNew->name); ?></p>
    <p>This is a confirmation that your email on Full Stack Test has been changed to: <br>
    <?php echo e($userNew->email); ?>

</p>
</div><?php /**PATH C:\xampp\htdocs\contact\resources\views/emails/updatedUser.blade.php ENDPATH**/ ?>