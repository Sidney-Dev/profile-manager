<?php $__env->startSection('content'); ?>
<div class="container">
               
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('message')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <button class="btn btn-primary mb-3 mt-3"><a class="cl-white" href="<?php echo e(route('contact.create')); ?>">Add Contact</a></button>
    <!-- LIST OF NAMES -->
    <contact-component />
    <!-- END OF LIST OF NAMES -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logged', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\contact\resources\views/home.blade.php ENDPATH**/ ?>