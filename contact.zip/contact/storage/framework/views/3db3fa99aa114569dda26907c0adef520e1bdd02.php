<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>New Contact</h1>

    <?php echo Form::open(['method'=>'POST', 'action'=> 'ContactController@store']); ?>


        <div class="form-group">
            <?php echo Form::label('name', 'Name:'); ?>

            <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('phone', 'Phone:'); ?>

            <?php echo Form::text('phone', null, ['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Save', ['class'=>'btn btn-primary']); ?>

        </div>

    <?php echo Form::close(); ?>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logged', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\contact\resources\views/contact/create.blade.php ENDPATH**/ ?>