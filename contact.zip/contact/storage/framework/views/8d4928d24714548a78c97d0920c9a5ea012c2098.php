<h1>Email sent to all users</h1>
Your account was created <?php echo e($user->created_at->diffForHumans()); ?>

Your name is <?php echo e($user->name); ?><?php /**PATH C:\xampp\htdocs\contact\resources\views/emails/broadcastusers.blade.php ENDPATH**/ ?>